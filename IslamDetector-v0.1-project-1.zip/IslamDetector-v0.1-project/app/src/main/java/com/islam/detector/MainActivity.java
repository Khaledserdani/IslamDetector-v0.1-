package com.islam.detector;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int stroke, int strokeColor, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        if (stroke > 0) g.setStroke(dp(stroke), strokeColor);
        return g;
    }
    private TextView card(String title, String body) {
        TextView v = new TextView(this);
        v.setText(title + "\n" + body); v.setTextColor(Color.WHITE); v.setTextSize(18); v.setGravity(Gravity.RIGHT);
        v.setPadding(dp(16),dp(16),dp(16),dp(16)); v.setBackground(bg(Color.rgb(13,37,48),1,Color.rgb(38,83,99),16));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); p.setMargins(0,dp(8),0,dp(8)); v.setLayoutParams(p); return v;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(16); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackground(bg(Color.rgb(19,91,88),0,0,14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,dp(52),1); p.setMargins(dp(4),dp(6),dp(4),dp(6)); b.setLayoutParams(p); return b;
    }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(Color.rgb(7,20,27));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(20),dp(16),dp(24)); root.setLayoutDirection(LinearLayout.LAYOUT_DIRECTION_RTL);
        TextView h = new TextView(this); h.setText("إسلام • كاشف المعادن PI\nالإصدار التجريبي v0.1"); h.setTextColor(Color.rgb(31,199,166)); h.setTextSize(24); h.setGravity(Gravity.RIGHT); h.setPadding(0,0,0,dp(12)); root.addView(h);
        root.addView(card("حالة الجهاز", "غير متصل • الكشف الخام يبقى أولوية النظام"));
        root.addView(card("نتيجة الجهاز", "بانتظار إشارة حقيقية من ESP32-S3\nالثقة: ــ   |   التصفير: ــ"));
        root.addView(card("الذكاء الاصطناعي", "تحليل واقتراح فقط، دون تعطيل هدف محتمل أو التحكم بالحماية."));
        root.addView(card("طبيب الجهاز", "الطاقة: ــ   |   الحرارة: ــ   |   TX: آمن/متوقف"));
        LinearLayout r1 = new LinearLayout(this); r1.setOrientation(LinearLayout.HORIZONTAL); r1.addView(button("إعادة المسح")); r1.addView(button("مقارنة")); root.addView(r1);
        LinearLayout r2 = new LinearLayout(this); r2.setOrientation(LinearLayout.HORIZONTAL); r2.addView(button("نتيجة الحفر")); r2.addView(button("حفظ")); root.addView(r2);
        root.addView(card("الخريطة والذاكرة", "GPS والخريطة الحرارية ومكتبة البصمات ستُربط تدريجياً على التطبيق نفسه."));
        scroll.addView(root); setContentView(scroll);
    }
}
